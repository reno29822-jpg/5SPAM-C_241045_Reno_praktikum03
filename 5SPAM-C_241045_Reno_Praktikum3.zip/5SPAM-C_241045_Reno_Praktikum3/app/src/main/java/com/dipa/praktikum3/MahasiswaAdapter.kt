package com.dipa.praktikum3

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.TextView

class MahasiswaAdapter(
    private val context: Context,
    private val dataSource: List<Mahasiswa>
) : BaseAdapter() {

    private val inflater = LayoutInflater.from(context)

    private class ViewHolder(
        val tvNama: TextView,
        val tvDetail: TextView
    )

    override fun getCount(): Int {
        return dataSource.size
    }

    override fun getItem(position: Int): Any {
        return dataSource[position]
    }

    override fun getItemId(position: Int): Long {
        return dataSource[position].id.toLong()
    }

    override fun getView(
        position: Int,
        convertView: View?,
        parent: ViewGroup
    ): View {

        val rowView: View
        val holder: ViewHolder

        if (convertView == null) {

            rowView = inflater.inflate(
                R.layout.item_mahasiswa,
                parent,
                false
            )

            holder = ViewHolder(
                rowView.findViewById(R.id.tvNama),
                rowView.findViewById(R.id.tvDetail)
            )

            rowView.tag = holder

        } else {

            rowView = convertView
            holder = rowView.tag as ViewHolder
        }

        val mahasiswa = dataSource[position]

        holder.tvNama.text = mahasiswa.nama

        holder.tvDetail.text =
            "${mahasiswa.nim} • ${mahasiswa.jurusan ?: "-"}"

        return rowView
    }
}
