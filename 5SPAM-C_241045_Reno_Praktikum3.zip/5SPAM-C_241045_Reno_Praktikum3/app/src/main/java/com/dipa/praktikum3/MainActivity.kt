package com.dipa.praktikum3

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var db: DatabaseHelper
    private lateinit var adapter: MahasiswaAdapter

    private val dataMahasiswa = mutableListOf<Mahasiswa>()

    private lateinit var etNim: EditText
    private lateinit var etNama: EditText
    private lateinit var etAlamat: EditText
    private lateinit var etJurusan: EditText
    private lateinit var etNomorHp: EditText

    private lateinit var btnSimpan: Button
    private lateinit var btnBatal: Button

    private var editId: Int? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Menghubungkan komponen XML
        etNim = findViewById(R.id.etNim)
        etNama = findViewById(R.id.etNama)
        etAlamat = findViewById(R.id.etAlamat)
        etJurusan = findViewById(R.id.etJurusan)
        etNomorHp = findViewById(R.id.etNomorHp)

        btnSimpan = findViewById(R.id.btnSimpan)
        btnBatal = findViewById(R.id.btnBatal)

        val listView = findViewById<ListView>(
            R.id.listMahasiswa
        )

        // Membuat database
        db = DatabaseHelper(this)

        // Menghubungkan adapter dengan ListView
        adapter = MahasiswaAdapter(
            this,
            dataMahasiswa
        )

        listView.adapter = adapter

        // Memuat data mahasiswa
        loadData()

        // Tombol simpan
        btnSimpan.setOnClickListener {
            simpan()
        }

        // Tombol batal
        btnBatal.setOnClickListener {
            resetForm()
        }

        // Ketuk satu kali untuk mengubah data
        listView.setOnItemClickListener {
                _, _, position, _ ->

            dataMahasiswa.getOrNull(position)?.let {
                isiForm(it)
            }
        }

        // Tekan lama untuk menghapus data
        listView.setOnItemLongClickListener {
                _, _, position, _ ->

            dataMahasiswa.getOrNull(position)?.let {
                konfirmasiHapus(it)
            }

            true
        }
    }

    // Mengambil data dari database
    private fun loadData() {
        dataMahasiswa.clear()
        dataMahasiswa.addAll(db.getAllMahasiswa())
        adapter.notifyDataSetChanged()
    }

    // Menyimpan atau memperbarui data
    private fun simpan() {

        val nim = etNim.text.toString().trim()
        val nama = etNama.text.toString().trim()
        val alamat = etAlamat.text.toString().trim()
        val jurusan = etJurusan.text.toString().trim()
        val nomorHp = etNomorHp.text.toString().trim()

        if (!validasi(nim, nama, nomorHp)) {
            return
        }

        val id = editId

        val mahasiswa = Mahasiswa(
            id = id ?: 0,
            nim = nim,
            nama = nama,
            alamat = alamat,
            jurusan = jurusan,
            nomorHp = nomorHp
        )

        val berhasil = if (id == null) {
            db.insertMahasiswa(mahasiswa) != -1L
        } else {
            db.updateMahasiswa(mahasiswa) > 0
        }

        if (berhasil) {

            val aksi = if (id == null) {
                "ditambahkan"
            } else {
                "diperbarui"
            }

            Toast.makeText(
                this,
                "Data berhasil $aksi",
                Toast.LENGTH_SHORT
            ).show()

            resetForm()
            loadData()

        } else {

            Toast.makeText(
                this,
                "Gagal menyimpan data",
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    // Validasi input
    private fun validasi(
        nim: String,
        nama: String,
        nomorHp: String
    ): Boolean {

        var valid = true

        etNim.error = null
        etNama.error = null
        etNomorHp.error = null

        if (nim.isEmpty()) {

            etNim.error = "NIM wajib diisi"
            valid = false

        } else if (
            nim.length < 5 ||
            !nim.all { it.isDigit() }
        ) {

            etNim.error = "NIM minimal 5 digit angka"
            valid = false

        } else if (
            db.isNimTerdaftar(nim, editId ?: 0)
        ) {

            etNim.error = "NIM sudah terdaftar"
            valid = false
        }

        if (nama.isEmpty()) {

            etNama.error = "Nama wajib diisi"
            valid = false
        }

        if (
            nomorHp.isNotEmpty() &&
            !hpValid(nomorHp)
        ) {

            etNomorHp.error =
                "Nomor HP tidak valid (contoh 081234567890)"

            valid = false
        }

        return valid
    }

    // Memeriksa format nomor HP
    private fun hpValid(hp: String): Boolean {
        return hp.startsWith("08") &&
                hp.length in 10..13 &&
                hp.all { it.isDigit() }
    }

    // Memasukkan data yang dipilih ke form
    private fun isiForm(mhs: Mahasiswa) {

        etNim.setText(mhs.nim)
        etNama.setText(mhs.nama)
        etAlamat.setText(mhs.alamat ?: "")
        etJurusan.setText(mhs.jurusan ?: "")
        etNomorHp.setText(mhs.nomorHp ?: "")

        editId = mhs.id

        btnSimpan.text = "Perbarui"
        btnBatal.visibility = View.VISIBLE
    }

    // Mengosongkan form
    private fun resetForm() {

        etNim.text.clear()
        etNama.text.clear()
        etAlamat.text.clear()
        etJurusan.text.clear()
        etNomorHp.text.clear()

        etNim.error = null
        etNama.error = null
        etAlamat.error = null
        etJurusan.error = null
        etNomorHp.error = null

        editId = null

        btnSimpan.text = "Simpan"
        btnBatal.visibility = View.GONE
    }

    // Konfirmasi penghapusan data
    private fun konfirmasiHapus(mhs: Mahasiswa) {

        AlertDialog.Builder(this)
            .setTitle("Hapus Data Mahasiswa")
            .setMessage(
                "Apakah kamu yakin ingin menghapus " +
                        "${mhs.nama} (${mhs.nim})?"
            )
            .setPositiveButton("Hapus") { _, _ ->

                if (db.deleteMahasiswa(mhs.id) > 0) {

                    Toast.makeText(
                        this,
                        "Data berhasil dihapus",
                        Toast.LENGTH_SHORT
                    ).show()

                    if (editId == mhs.id) {
                        resetForm()
                    }

                    loadData()

                } else {

                    Toast.makeText(
                        this,
                        "Gagal menghapus data",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    override fun onDestroy() {
        if (::db.isInitialized) {
            db.close()
        }

        super.onDestroy()
    }
}
