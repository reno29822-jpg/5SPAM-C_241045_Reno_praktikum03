package com.dipa.praktikum3

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DatabaseHelper(context: Context) :
    SQLiteOpenHelper(context, DB_NAME, null, DB_VERSION) {

    companion object {
        private const val DB_NAME = "praktikum.db"
        private const val DB_VERSION = 3

        const val TABLE_MAHASISWA = "mahasiswa"
    }

    override fun onCreate(db: SQLiteDatabase) {
        createTable(db)
        seedData(db)
    }

    private fun createTable(db: SQLiteDatabase) {
        val sql = """
            CREATE TABLE IF NOT EXISTS $TABLE_MAHASISWA (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nim TEXT NOT NULL UNIQUE,
                nama TEXT NOT NULL,
                alamat TEXT,
                jurusan TEXT,
                nomor_hp TEXT
            )
        """.trimIndent()

        db.execSQL(sql)
    }

    override fun onUpgrade(
        db: SQLiteDatabase,
        oldVersion: Int,
        newVersion: Int
    ) {
        createTable(db)

        ensureColumn(db, "alamat")
        ensureColumn(db, "jurusan")
        ensureColumn(db, "nomor_hp")
    }

    private fun ensureColumn(
        db: SQLiteDatabase,
        column: String
    ) {
        val cursor = db.rawQuery(
            "PRAGMA table_info($TABLE_MAHASISWA)",
            null
        )

        val exists = cursor.use {
            val index = it.getColumnIndexOrThrow("name")
            var found = false

            while (it.moveToNext()) {
                if (it.getString(index) == column) {
                    found = true
                    break
                }
            }

            found
        }

        if (!exists) {
            db.execSQL(
                "ALTER TABLE $TABLE_MAHASISWA ADD COLUMN $column TEXT"
            )
        }
    }

    private fun seedData(db: SQLiteDatabase) {
        val seed = listOf(
            Mahasiswa(
                nim = "21001",
                nama = "Ahmad Fauzi",
                alamat = "Jl. Pettarani No. 5",
                jurusan = "Sistem Informasi",
                nomorHp = "081234567890"
            ),
            Mahasiswa(
                nim = "21002",
                nama = "Siti Nurhaliza",
                alamat = "Jl. Perintis Kemerdekaan",
                jurusan = "Sistem Informasi",
                nomorHp = "082198765432"
            ),
            Mahasiswa(
                nim = "21003",
                nama = "Budi Santoso",
                alamat = "Jl. Rappocini No. 12",
                jurusan = "Sistem Informasi",
                nomorHp = "081345678901"
            )
        )

        seed.forEach {
            db.insert(TABLE_MAHASISWA, null, toValues(it))
        }
    }

    private fun toValues(mhs: Mahasiswa): ContentValues {
        return ContentValues().apply {
            put("nim", mhs.nim)
            put("nama", mhs.nama)
            put("alamat", mhs.alamat)
            put("jurusan", mhs.jurusan)
            put("nomor_hp", mhs.nomorHp)
        }
    }

    fun insertMahasiswa(mhs: Mahasiswa): Long {
        return writableDatabase.insert(
            TABLE_MAHASISWA,
            null,
            toValues(mhs)
        )
    }

    fun updateMahasiswa(mhs: Mahasiswa): Int {
        return writableDatabase.update(
            TABLE_MAHASISWA,
            toValues(mhs),
            "id = ?",
            arrayOf(mhs.id.toString())
        )
    }

    fun deleteMahasiswa(id: Int): Int {
        return writableDatabase.delete(
            TABLE_MAHASISWA,
            "id = ?",
            arrayOf(id.toString())
        )
    }

    fun isNimTerdaftar(
        nim: String,
        exceptId: Int = 0
    ): Boolean {
        val cursor = readableDatabase.query(
            TABLE_MAHASISWA,
            arrayOf("id"),
            "nim = ? AND id != ?",
            arrayOf(nim, exceptId.toString()),
            null,
            null,
            null
        )

        return cursor.use {
            it.moveToFirst()
        }
    }

    fun getAllMahasiswa(): List<Mahasiswa> {
        val list = mutableListOf<Mahasiswa>()

        val cursor = readableDatabase.query(
            TABLE_MAHASISWA,
            null,
            null,
            null,
            null,
            null,
            "nama ASC"
        )

        cursor.use {
            while (it.moveToNext()) {
                list.add(
                    Mahasiswa(
                        id = it.getInt(
                            it.getColumnIndexOrThrow("id")
                        ),
                        nim = it.getString(
                            it.getColumnIndexOrThrow("nim")
                        ),
                        nama = it.getString(
                            it.getColumnIndexOrThrow("nama")
                        ),
                        alamat = it.getString(
                            it.getColumnIndexOrThrow("alamat")
                        ),
                        jurusan = it.getString(
                            it.getColumnIndexOrThrow("jurusan")
                        ),
                        nomorHp = it.getString(
                            it.getColumnIndexOrThrow("nomor_hp")
                        )
                    )
                )
            }
        }

        return list
    }
}
